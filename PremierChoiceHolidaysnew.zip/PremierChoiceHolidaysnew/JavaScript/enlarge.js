// JavaScript Document
function enlargeImage2(){ // Image Id
	image2.height="300" // enlarge height
	image2.width="450" // enlarge width
	document.getElementById('text2').style.visibility="visible"; // Sets ID to visible
}
function dropImage2(){ // Image Id
   image2.height="200" // default height
   image2.width="270" // default width
   document.getElementById('text2').style.visibility="hidden"; // Sets ID to hidden
}

function enlargeImage3(){
	image3.height="300"
	image3.width="450"
	document.getElementById('text3').style.visibility="visible";	
}
function dropImage3(){
   image3.height="200" 
   image3.width="270"
   document.getElementById('text3').style.visibility="hidden";   
}

function enlargeImage4(){
	image4.height="300"
	image4.width="450"
	document.getElementById('text4').style.visibility="visible";	
}
function dropImage4(){
   image4.height="200" 
   image4.width="270"
   document.getElementById('text4').style.visibility="hidden";   
}

function enlargeImage5(){
	image5.height="300"
	image5.width="450"
	document.getElementById('text5').style.visibility="visible";	
}
function dropImage5(){
   image5.height="200" 
   image5.width="270"
   document.getElementById('text5').style.visibility="hidden";   
}

function enlargeImage6(){
	image6.height="300"
	image6.width="450"
	document.getElementById('text6').style.visibility="visible";	
}
function dropImage6(){
   image6.height="200" 
   image6.width="270"
   document.getElementById('text6').style.visibility="hidden";   
}